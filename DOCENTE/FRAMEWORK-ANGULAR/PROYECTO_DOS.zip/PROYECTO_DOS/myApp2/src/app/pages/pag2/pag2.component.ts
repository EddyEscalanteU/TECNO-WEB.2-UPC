import { Component } from '@angular/core';
import { TimelineComponent } from '../../componentes/timeline/timeline.component';

@Component({
  selector: 'app-pag2',
  standalone: true,
  imports: [TimelineComponent],
  templateUrl: './pag2.component.html',
  styleUrl: './pag2.component.scss'
})
export class Pag2Component {

}
