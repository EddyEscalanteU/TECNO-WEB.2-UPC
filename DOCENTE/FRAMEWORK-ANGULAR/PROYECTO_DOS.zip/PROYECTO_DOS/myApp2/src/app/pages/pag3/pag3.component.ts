import { Component } from '@angular/core';
import { TitulosComponent } from '../../componentes/titulos/titulos.component';

@Component({
  selector: 'app-pag3',
  standalone: true,
  imports: [TitulosComponent],
  templateUrl: './pag3.component.html',
  styleUrl: './pag3.component.scss'
})
export class Pag3Component {

}
