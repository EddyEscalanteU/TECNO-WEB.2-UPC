export * from './lib/posts/posts.component';
